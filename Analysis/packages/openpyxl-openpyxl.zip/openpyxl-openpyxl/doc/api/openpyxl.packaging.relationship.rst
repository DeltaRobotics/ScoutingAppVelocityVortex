openpyxl.packaging.relationship module
======================================

.. automodule:: openpyxl.packaging.relationship
    :members:
    :undoc-members:
    :show-inheritance:
