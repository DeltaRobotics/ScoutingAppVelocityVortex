openpyxl.worksheet.filters module
=================================

.. automodule:: openpyxl.worksheet.filters
    :members:
    :undoc-members:
    :show-inheritance:
