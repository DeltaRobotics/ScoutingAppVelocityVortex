openpyxl.worksheet.properties module
====================================

.. automodule:: openpyxl.worksheet.properties
    :members:
    :undoc-members:
    :show-inheritance:
