openpyxl.drawing.fill module
============================

.. automodule:: openpyxl.drawing.fill
    :members:
    :undoc-members:
    :show-inheritance:
