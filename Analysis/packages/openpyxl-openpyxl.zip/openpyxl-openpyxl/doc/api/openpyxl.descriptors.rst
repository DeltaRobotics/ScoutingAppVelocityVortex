openpyxl.descriptors package
============================

.. automodule:: openpyxl.descriptors
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   openpyxl.descriptors.base
   openpyxl.descriptors.excel
   openpyxl.descriptors.namespace
   openpyxl.descriptors.nested
   openpyxl.descriptors.sequence
   openpyxl.descriptors.serialisable

