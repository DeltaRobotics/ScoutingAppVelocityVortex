openpyxl.utils.escape module
============================

.. automodule:: openpyxl.utils.escape
    :members:
    :undoc-members:
    :show-inheritance:
