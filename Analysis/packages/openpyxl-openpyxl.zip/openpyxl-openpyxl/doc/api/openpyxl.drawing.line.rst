openpyxl.drawing.line module
============================

.. automodule:: openpyxl.drawing.line
    :members:
    :undoc-members:
    :show-inheritance:
