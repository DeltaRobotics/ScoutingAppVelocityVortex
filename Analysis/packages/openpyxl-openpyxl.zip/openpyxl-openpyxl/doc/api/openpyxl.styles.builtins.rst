openpyxl.styles.builtins module
===============================

.. automodule:: openpyxl.styles.builtins
    :members:
    :undoc-members:
    :show-inheritance:
