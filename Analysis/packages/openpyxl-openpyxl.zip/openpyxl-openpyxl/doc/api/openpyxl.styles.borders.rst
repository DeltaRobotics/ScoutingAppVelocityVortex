openpyxl.styles.borders module
==============================

.. automodule:: openpyxl.styles.borders
    :members:
    :undoc-members:
    :show-inheritance:
