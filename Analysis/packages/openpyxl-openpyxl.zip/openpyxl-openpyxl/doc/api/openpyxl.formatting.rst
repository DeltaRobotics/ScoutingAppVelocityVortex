openpyxl.formatting package
===========================

.. automodule:: openpyxl.formatting
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   openpyxl.formatting.formatting
   openpyxl.formatting.rule

