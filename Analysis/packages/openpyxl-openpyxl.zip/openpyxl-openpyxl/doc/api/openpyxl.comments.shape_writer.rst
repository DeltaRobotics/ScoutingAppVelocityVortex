openpyxl.comments.shape_writer module
=====================================

.. automodule:: openpyxl.comments.shape_writer
    :members:
    :undoc-members:
    :show-inheritance:
