openpyxl.chart.series module
============================

.. automodule:: openpyxl.chart.series
    :members:
    :undoc-members:
    :show-inheritance:
