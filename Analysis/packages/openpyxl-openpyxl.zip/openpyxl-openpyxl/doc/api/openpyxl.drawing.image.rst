openpyxl.drawing.image module
=============================

.. automodule:: openpyxl.drawing.image
    :members:
    :undoc-members:
    :show-inheritance:
