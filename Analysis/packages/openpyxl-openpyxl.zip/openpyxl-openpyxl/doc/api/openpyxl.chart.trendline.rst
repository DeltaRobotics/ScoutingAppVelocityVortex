openpyxl.chart.trendline module
===============================

.. automodule:: openpyxl.chart.trendline
    :members:
    :undoc-members:
    :show-inheritance:
