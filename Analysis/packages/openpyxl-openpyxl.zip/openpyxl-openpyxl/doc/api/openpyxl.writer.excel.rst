openpyxl.writer.excel module
============================

.. automodule:: openpyxl.writer.excel
    :members:
    :undoc-members:
    :show-inheritance:
