openpyxl.chart.scatter_chart module
===================================

.. automodule:: openpyxl.chart.scatter_chart
    :members:
    :undoc-members:
    :show-inheritance:
