openpyxl.workbook.properties module
===================================

.. automodule:: openpyxl.workbook.properties
    :members:
    :undoc-members:
    :show-inheritance:
