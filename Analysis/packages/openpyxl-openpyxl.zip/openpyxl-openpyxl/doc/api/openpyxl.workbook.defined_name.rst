openpyxl.workbook.defined_name module
=====================================

.. automodule:: openpyxl.workbook.defined_name
    :members:
    :undoc-members:
    :show-inheritance:
