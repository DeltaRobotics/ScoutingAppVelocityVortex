openpyxl.worksheet.dimensions module
====================================

.. automodule:: openpyxl.worksheet.dimensions
    :members:
    :undoc-members:
    :show-inheritance:
