openpyxl.drawing.effect module
==============================

.. automodule:: openpyxl.drawing.effect
    :members:
    :undoc-members:
    :show-inheritance:
