openpyxl.utils.datetime module
==============================

.. automodule:: openpyxl.utils.datetime
    :members:
    :undoc-members:
    :show-inheritance:
