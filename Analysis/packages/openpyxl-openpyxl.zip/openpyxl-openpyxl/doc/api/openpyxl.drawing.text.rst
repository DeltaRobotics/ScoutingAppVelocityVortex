openpyxl.drawing.text module
============================

.. automodule:: openpyxl.drawing.text
    :members:
    :undoc-members:
    :show-inheritance:
