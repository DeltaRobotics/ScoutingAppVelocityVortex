openpyxl.chart.descriptors module
=================================

.. automodule:: openpyxl.chart.descriptors
    :members:
    :undoc-members:
    :show-inheritance:
