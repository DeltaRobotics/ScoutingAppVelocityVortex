openpyxl.cell.read_only module
==============================

.. automodule:: openpyxl.cell.read_only
    :members:
    :undoc-members:
    :show-inheritance:
