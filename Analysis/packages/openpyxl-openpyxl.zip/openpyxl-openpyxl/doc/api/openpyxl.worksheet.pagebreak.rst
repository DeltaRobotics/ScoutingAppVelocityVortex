openpyxl.worksheet.pagebreak module
===================================

.. automodule:: openpyxl.worksheet.pagebreak
    :members:
    :undoc-members:
    :show-inheritance:
