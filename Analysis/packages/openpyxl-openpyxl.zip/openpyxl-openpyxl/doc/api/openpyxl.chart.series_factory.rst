openpyxl.chart.series_factory module
====================================

.. automodule:: openpyxl.chart.series_factory
    :members:
    :undoc-members:
    :show-inheritance:
