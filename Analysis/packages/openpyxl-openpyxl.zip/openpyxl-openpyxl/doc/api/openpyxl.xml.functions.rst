openpyxl.xml.functions module
=============================

.. automodule:: openpyxl.xml.functions
    :members:
    :undoc-members:
    :show-inheritance:
