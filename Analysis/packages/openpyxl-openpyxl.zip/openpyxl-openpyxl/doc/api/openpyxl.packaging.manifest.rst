openpyxl.packaging.manifest module
==================================

.. automodule:: openpyxl.packaging.manifest
    :members:
    :undoc-members:
    :show-inheritance:
