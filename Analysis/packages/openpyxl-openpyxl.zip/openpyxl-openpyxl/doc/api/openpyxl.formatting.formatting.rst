openpyxl.formatting.formatting module
=====================================

.. automodule:: openpyxl.formatting.formatting
    :members:
    :undoc-members:
    :show-inheritance:
