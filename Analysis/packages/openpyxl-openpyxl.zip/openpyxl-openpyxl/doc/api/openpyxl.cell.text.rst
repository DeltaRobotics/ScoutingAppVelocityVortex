openpyxl.cell.text module
=========================

.. automodule:: openpyxl.cell.text
    :members:
    :undoc-members:
    :show-inheritance:
