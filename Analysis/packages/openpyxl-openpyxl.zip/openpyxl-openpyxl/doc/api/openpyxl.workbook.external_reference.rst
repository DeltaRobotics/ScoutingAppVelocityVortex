openpyxl.workbook.external_reference module
===========================================

.. automodule:: openpyxl.workbook.external_reference
    :members:
    :undoc-members:
    :show-inheritance:
