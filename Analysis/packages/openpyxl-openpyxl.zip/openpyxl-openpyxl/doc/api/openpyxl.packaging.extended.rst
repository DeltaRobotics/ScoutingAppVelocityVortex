openpyxl.packaging.extended module
==================================

.. automodule:: openpyxl.packaging.extended
    :members:
    :undoc-members:
    :show-inheritance:
