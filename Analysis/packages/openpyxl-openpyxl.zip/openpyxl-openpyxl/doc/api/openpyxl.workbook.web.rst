openpyxl.workbook.web module
============================

.. automodule:: openpyxl.workbook.web
    :members:
    :undoc-members:
    :show-inheritance:
