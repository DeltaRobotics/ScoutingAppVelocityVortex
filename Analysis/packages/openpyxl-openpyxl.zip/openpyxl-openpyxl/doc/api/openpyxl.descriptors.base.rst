openpyxl.descriptors.base module
================================

.. automodule:: openpyxl.descriptors.base
    :members:
    :undoc-members:
    :show-inheritance:
