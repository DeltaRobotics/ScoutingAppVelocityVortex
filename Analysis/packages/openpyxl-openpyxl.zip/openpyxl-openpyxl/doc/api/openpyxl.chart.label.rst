openpyxl.chart.label module
===========================

.. automodule:: openpyxl.chart.label
    :members:
    :undoc-members:
    :show-inheritance:
