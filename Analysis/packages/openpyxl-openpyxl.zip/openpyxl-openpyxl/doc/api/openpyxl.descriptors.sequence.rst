openpyxl.descriptors.sequence module
====================================

.. automodule:: openpyxl.descriptors.sequence
    :members:
    :undoc-members:
    :show-inheritance:
