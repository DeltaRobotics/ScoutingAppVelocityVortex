openpyxl.worksheet.merge module
===============================

.. automodule:: openpyxl.worksheet.merge
    :members:
    :undoc-members:
    :show-inheritance:
