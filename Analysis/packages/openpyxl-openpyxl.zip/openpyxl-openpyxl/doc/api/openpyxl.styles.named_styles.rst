openpyxl.styles.named_styles module
===================================

.. automodule:: openpyxl.styles.named_styles
    :members:
    :undoc-members:
    :show-inheritance:
