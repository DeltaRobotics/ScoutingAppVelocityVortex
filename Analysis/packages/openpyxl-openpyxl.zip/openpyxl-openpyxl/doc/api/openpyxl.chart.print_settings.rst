openpyxl.chart.print_settings module
====================================

.. automodule:: openpyxl.chart.print_settings
    :members:
    :undoc-members:
    :show-inheritance:
