openpyxl.chart.updown_bars module
=================================

.. automodule:: openpyxl.chart.updown_bars
    :members:
    :undoc-members:
    :show-inheritance:
