openpyxl.packaging.interface module
===================================

.. automodule:: openpyxl.packaging.interface
    :members:
    :undoc-members:
    :show-inheritance:
