openpyxl.drawing.colors module
==============================

.. automodule:: openpyxl.drawing.colors
    :members:
    :undoc-members:
    :show-inheritance:
