openpyxl.styles.proxy module
============================

.. automodule:: openpyxl.styles.proxy
    :members:
    :undoc-members:
    :show-inheritance:
