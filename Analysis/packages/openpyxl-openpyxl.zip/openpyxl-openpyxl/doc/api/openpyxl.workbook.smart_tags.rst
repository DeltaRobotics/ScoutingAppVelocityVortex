openpyxl.workbook.smart_tags module
===================================

.. automodule:: openpyxl.workbook.smart_tags
    :members:
    :undoc-members:
    :show-inheritance:
