openpyxl.chart.area_chart module
================================

.. automodule:: openpyxl.chart.area_chart
    :members:
    :undoc-members:
    :show-inheritance:
