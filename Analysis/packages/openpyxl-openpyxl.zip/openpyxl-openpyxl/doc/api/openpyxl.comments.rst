openpyxl.comments package
=========================

.. automodule:: openpyxl.comments
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   openpyxl.comments.author
   openpyxl.comments.comment_sheet
   openpyxl.comments.comments
   openpyxl.comments.shape_writer

