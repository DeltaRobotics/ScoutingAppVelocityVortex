openpyxl.chart.shapes module
============================

.. automodule:: openpyxl.chart.shapes
    :members:
    :undoc-members:
    :show-inheritance:
