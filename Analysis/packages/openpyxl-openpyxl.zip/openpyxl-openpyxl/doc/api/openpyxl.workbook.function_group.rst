openpyxl.workbook.function_group module
=======================================

.. automodule:: openpyxl.workbook.function_group
    :members:
    :undoc-members:
    :show-inheritance:
