openpyxl.styles.fonts module
============================

.. automodule:: openpyxl.styles.fonts
    :members:
    :undoc-members:
    :show-inheritance:
