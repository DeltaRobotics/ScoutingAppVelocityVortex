openpyxl.workbook.pivot module
==============================

.. automodule:: openpyxl.workbook.pivot
    :members:
    :undoc-members:
    :show-inheritance:
