openpyxl.workbook.external_link.external module
===============================================

.. automodule:: openpyxl.workbook.external_link.external
    :members:
    :undoc-members:
    :show-inheritance:
