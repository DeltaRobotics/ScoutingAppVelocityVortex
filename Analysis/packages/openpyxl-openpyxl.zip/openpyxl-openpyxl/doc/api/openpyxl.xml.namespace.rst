openpyxl.xml.namespace module
=============================

.. automodule:: openpyxl.xml.namespace
    :members:
    :undoc-members:
    :show-inheritance:
