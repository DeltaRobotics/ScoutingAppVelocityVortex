openpyxl.styles.styleable module
================================

.. automodule:: openpyxl.styles.styleable
    :members:
    :undoc-members:
    :show-inheritance:
