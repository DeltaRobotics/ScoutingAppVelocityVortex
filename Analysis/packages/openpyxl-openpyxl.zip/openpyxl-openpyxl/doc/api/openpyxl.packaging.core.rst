openpyxl.packaging.core module
==============================

.. automodule:: openpyxl.packaging.core
    :members:
    :undoc-members:
    :show-inheritance:
